#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <climits>

using namespace std;

// Structure to represent an edge between two cities
struct Edge
{
    int destination;
    int capacity;
};

// Function to print the graph
void printGraph(const vector<vector<Edge>> &graph)
{
    cout << "Graph:" << endl;
    for (int i = 1; i < graph.size(); ++i)
    {
        cout << "City " << i << ": ";
        for (const Edge &edge : graph[i])
        {
            cout << "(" << edge.destination << ", " << edge.capacity << ") ";
        }
        cout << endl;
    }
}

// Function to perform BFS and find the minimum number of trips
int minTrips(vector<vector<Edge>> &graph, int start, int destination, int tourists)
{
    queue<int> q;                              // Queue for BFS traversal
    vector<bool> visited(graph.size(), false); // Visited array to mark visited cities

    q.push(start); // Push start city
    visited[start] = true;

    cout << "BFS Traversal:" << endl;

    while (!q.empty())
    {
        int currentCity = q.front();
        q.pop();

        cout << "Visiting city " << currentCity << endl;

        if (currentCity == destination)
        {
            cout << "Destination city reached." << endl;
            return 1;
        }

        // Traverse through adjacent cities
        for (const Edge &edge : graph[currentCity])
        {
            if (!visited[edge.destination])
            {
                q.push(edge.destination);
                visited[edge.destination] = true;
                cout << "Considering edge (" << currentCity << ", " << edge.destination << ")" << endl;
            }
        }
    }

    // If destination is unreachable
    cout << "Destination city is unreachable." << endl;
    return 0;
}

int main()
{
    ifstream inputFile("data.txt");
    if (!inputFile)
    {
        cerr << "Failed to open input file!" << endl;
        return 1;
    }

    int N, R;
    inputFile >> N >> R;

    vector<vector<Edge>> graph(N + 1); // 1-based indexing for cities

    // Input road segments
    for (int i = 0; i < R; ++i)
    {
        int C1, C2, P;
        inputFile >> C1 >> C2 >> P;
        graph[C1].push_back({C2, P});
        graph[C2].push_back({C1, P}); // Since the graph is undirected
    }

    printGraph(graph); // Print the constructed graph

    int start, destination, tourists;
    inputFile >> start >> destination >> tourists;

    inputFile.close();

    int minTripsRequired = minTrips(graph, start, destination, tourists);
    cout << "Minimum number of trips required: " << minTripsRequired << endl;

    return 0;
}